<?php
$connect = mysqli_connect('localhost', 'root', '', 'homeservice');
if (!$connect) {
    die('could not connect:');
}
?>

<?php
$del_rec = $_GET['del'];
$sql = "DELETE FROM tblprofile WHERE id='$del_rec'";

if (mysqli_query($connect, $sql)) {
    echo "<script>window.open('mngprofile.php? deleted=Record Deleted','_self')</script>";
}

?>