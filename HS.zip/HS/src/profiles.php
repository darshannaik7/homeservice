<?php
require_once "config.php";
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home service</title>

    <!--home service-->
    <link rel="icon" href="../assets/logo1.png">
    <!--css-->
    <link rel="stylesheet" href="../css/style2.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <!--bootstrap-->
    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>

    <!--themifi-->
    <link rel="stylesheet" href="../css/themify-icons.css">


</head>

<body>
    <Header>

        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                    <img src="../assets/logo1.png">
                    Home service
                </a>
                <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbar">
                    <span class="ti-align-justify navbar-toggler-icon "></span>
                </button>
                <div class="navbar-collapse collapse" id="navbar">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="mybookings.php">My Bookings</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profiles.php">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>

                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="part1">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <h1>Make your carior with home service</h1>
                        <p>Join with us and make this world smart </p>

                    </div>
                    <div class="col-md-5">
                        <div class="png">
                            <img src="../assets/head.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="profile">
        <div class="row">
            <div class="col-md-6 ">
                <h2>You Want To Become A Service Man With us</h2>
                <p>Create your account By clicking on this button</p>
                <a href="registration.php"><button type="button" class="btn btn-light">Create
                        New
                        Profile</button></a>
            </div>
            <div class="col-md-4">
                <h2>Allready Have a account?</h2>
                <h5>Please Login</h5>
                <button type="button" class="btn btn-light" data-bs-toggle="modal"
                    data-bs-target="#exampleModal2">Login</button>
            </div>
        </div>
    </div>



    <!-- Modal register -->
    <div class="modal1">
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-body">
                        <div align="right"><button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button></div>
                        <div class="form">

                            <div class="text">
                                <h1>Registration Form</h1>
                            </div>
                            <form action="#">

                                <input type="text" placeholder="First Name">
                                <input type="text" placeholder="Last Name">

                                <input type="email" placeholder="Email">
                                <input type="password" placeholder="Password">
                                <input type="password" placeholder="Confirm Password">
                                <div class="rbt">
                                    <input type="submit" value="Register">
                                </div>

                            </form>
                        </div>
                        <div class="modal-footer">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Login -->
    <div class="modal2">
        <div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-body">
                        <div align="right"><button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button></div>
                        <div class="form">

                            <div class="profiles.php">
                                <h1>Login Form</h1>
                            </div>
                            <form action="profiles.php" method="POST">

                                <input type="email" placeholder="Email" id="email" name="email">
                                <input type="password" placeholder="Password" id="password" name="password">
                                <div class="rbt">
                                    <input type="submit" value="Login" name="btn_login">
                                </div>
                                <a href=" myprofile.php">forgot password?</a>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>




    <?php
    if (isset($_POST['btn_login'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql1 = "SELECT * FROM tblprofile WHERE email='$email' AND pasword='$password'";

        $result = mysqli_query($connect, $sql1);

        if (mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);

            if ($row['email'] === $email && $row['pasword'] === $password) {

                $id = $row['id'];

                //echo "Logged in!";
                echo '<script> alert("Login success") </script>';
                echo "<script type='text/javascript'> document.location ='myprofile.php?id=$id'; </script>";
            }
        } else {
            echo '<script> alert("Login Failed") </script>';
        }
    }
    ?>




    <div class="footer">
        <p>copyright @homeservice 2022</p>
    </div>
</body>

</html>