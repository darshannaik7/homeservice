<?php
/*  This file contain database config*/

$connect = mysqli_connect('localhost', 'root', '', 'homeservice');
if (!$connect) {
    die('could not connect:');
}