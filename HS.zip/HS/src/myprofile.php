<?php
require_once "config.php";
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>hs</title>

    <!--home service-->
    <link rel="icon" href="../assets/logo1.png">
    <!--css-->
    <link rel="stylesheet" href="../css/myprofile.css">

    <!--bootstrap-->
    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">

    <script src="../bootstrap/bootstrap.min.js"></script>
    <script src="../bootstrap/jquery.min.js"></script>
    <!--themifi-->
    <link rel="stylesheet" href="../css/themify-icons.css">

</head>

<body>
    <Header>

        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                    <img src="../assets/logo1.png">
                    Home service
                </a>
                <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbar">
                    <span class="ti-align-justify navbar-toggler-icon "></span>
                </button>
                <div class="navbar-collapse collapse" id="navbar">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="myorders.php">My Orders</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profiles.php">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>
                        <li><a href="logout.php">Log out</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </Header>

    <?php


    $id = $_GET['id'];
    $query = "SELECT * FROM tblprofile WHERE id='$id'";
    $result = mysqli_query($connect, $query);
    $row = mysqli_fetch_array($result)
    ?>



    <section>

        <div class="row">
            <div class="col-md-12">
                <div class="profile">
                    <div class="content">
                        <div class="row">

                            <div class="col-md-4">
                                <i class="ti-user "></i>
                                <h4><?php echo $row['first_name'];
                                    echo " "; ?><?php echo $row['last_name']; ?></h4>
                                <h5><?php echo $row['product'];
                                    echo " service" ?></h5>

                                <div class="ti-pencil-alt">

                                </div>
                            </div>
                            <div class="col-md-8">
                                <h3>Information</h3>
                                <hr class="badge-primary" width="100%">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h5>Address:</h5>
                                        <h6><?php echo $row['tbladdress']; ?></h6>
                                    </div>
                                    <div class="col-md-6">
                                        <h5>City:</h5>
                                        <h6><?php echo $row['city']; ?></h6>
                                    </div>
                                    <hr class="badge-primary" width="100%">
                                    <div class="col-md-6">
                                        <h5>Mobile no:</h5>
                                        <h6><?php echo $row['mobile']; ?></h6>
                                    </div>
                                    <div class="col-md-6">
                                        <h5>Email ID:</h5>
                                        <h6><?php echo $row['email']; ?></h6>
                                    </div>
                                    <hr class="badge-primary" width="100%">
                                    <div class="col-md-6">
                                        <h5>Gender:</h5>
                                        <h6><?php echo $row['gender']; ?></h6>
                                    </div>
                                    <div class="col-md-6">
                                        <h5>Qualification/Experience</h5>
                                        <h6><?php echo $row['qualification']; ?></h6>
                                    </div>

                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</body>

</html>