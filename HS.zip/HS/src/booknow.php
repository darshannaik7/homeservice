<?php
require_once "config.php";
?>
<?php


?>


<!DOCTYPE html>
<html lang="en">


<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home service</title>

<!--home service-->
<link rel="icon" href="../assets/logo1.png">
<!--css-->
<link rel="stylesheet" href="../css/booknow.css">

<!--bootstrap-->
<link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
<script src="../bootstrap/bootstrap.min.js"></script>
<!--themifi-->
<link rel="stylesheet" href="../css/themify-icons.css">


</head>

<body>
    <Header>

        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                    <img src="../assets/logo1.png">
                    Home service
                </a>
                <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbar">
                    <span class="ti-align-justify navbar-toggler-icon "></span>
                </button>
                <div class="navbar-collapse collapse" id="navbar">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="mybookings.php">My Bookings</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profiles.php">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>

                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </Header>
    <div class="content">
        <div class="container text-center">
            <h1>Choose The Service You Want</h1>
        </div>
        <div class="container-fluid">
            <div class="products">

                <!--php form display service-->


                <?php
                $query = "SELECT*FROM services ORDER BY name ASC";
                $result = mysqli_query($connect, $query);



                ?>

                <?php
                $i = 1;
                while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="card">
                    <?php $name = $row['name'];
                        ?>
                    <a href="selectperson.php?name=<?php echo $row['name']; ?>">
                        <div class=" card-img-top">

                            <div class="<?php echo $row['icon']; ?>">

                            </div>
                        </div>
                        <div class=" card-body">
                            <p class="card-title"> <?php echo $row['name']; ?></p>

                        </div>
                    </a>
                </div>
                <?php $i++;
                }
                mysqli_close($connect); ?>

                <!--


                <div class="card">
                    <a href="selectperson.php">
                        <div class="card-img-top">

                            <div class="ti-mobile">

                            </div>
                        </div>
                        <div class=" card-body">
                            <p class="card-title"> Mobile</p>

                        </div>
                    </a>
                </div>
                <div class="card">
                    <a href="selectperson.php">
                        <div class="card-img-top">

                            <div class="ti-light-bulb">

                            </div>
                        </div>
                        <div class=" card-body">
                            <p class="card-title"> Electricity</p>

                        </div>
                    </a>
                </div>
                <div class="card">
                    <a href="selectperson.php">
                        <div class="card-img-top">

                            <div class="ti-paint-roller">

                            </div>
                        </div>
                        <div class=" card-body">
                            <p class="card-title"> Panting</p>

                        </div>
                    </a>
                </div>
                <div class="card">
                    <a href="selectperson.php">
                        <div class="card-img-top">

                            <div class="ti-car">

                            </div>
                        </div>
                        <div class=" card-body">
                            <p class="card-title"> Car</p>

                        </div>
                    </a>
                </div>
                <div class="card">
                    <a href="selectperson.php">
                        <div class="card-img-top">

                            <div class="ti-rss-alt">

                            </div>
                        </div>
                        <div class=" card-body">
                            <p class="card-title"> Brodbrand</p>

                        </div>
                    </a>
                </div>-->

            </div>
        </div>
    </div>
</body>

</html>