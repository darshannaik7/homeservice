<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home service</title>

    <!--home service-->
    <link rel="icon" href="../assets/logo1.png">
    <!--css-->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <!--bootstrap-->
    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">

    <!--themifi-->
    <link rel="stylesheet" href="../css/themify-icons.css">
    <script src="../bootstrap/bootstrap.min.js"></script>

</head>

<body>
    <Header>

        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                    <img src="../assets/logo1.png">
                    Home service
                </a>
                <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbar">
                    <span class="ti-align-justify navbar-toggler-icon "></span>
                </button>
                <div class="navbar-collapse collapse" id="navbar">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="mybookings.php">My Bookings</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profiles.php">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>

                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="part1">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <h4>Hello!</h4>
                        <h1>Welcome to service man's center</h1>
                        <p>Here, Service Man’s for home appliances and electronic gadgets. And also for home
                            interior
                            designs
                            and constructions are available</p>
                        <a href="booknow.php"><button type="button" class="btn btn-light">Book Now</button>
                        </a>
                    </div>
                    <div class="col-md-5">
                        <div class="png">
                            <img src="../assets/head.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="part2">
        <div class="container">
            <h2>Our Highlights</h2>

        </div>

        <div class="row">
            <div class="col-md-6">
                <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="../assets/saloon.jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="../assets/tv.jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="../assets/inti.jpg" class="d-block w-100" alt="...">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
                        data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
                        data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
            <div class="col-md-6">
                <div id="carouselExampleControls2" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="../assets/electronic.jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="../assets/furniture.jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="../assets/painting.jpg" class="d-block w-100" alt="...">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls2"
                        data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls2"
                        data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="part3">
        <div class="container">
            <h1>Hey! you want to book a Service Man?</h1>
            <p>Press This Button</p>
            <a href="booknow.php"> <button type="button" class="btn">Book Now</button>
            </a>
        </div>
    </div>

    <div class="part4">
        <div class="container">
            <h2>Top profile's</h2>

        </div>

        <div class="row">
            <div class="col-md-4 ">
                <div id="carouselExampleControls3" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="card mr-2 d-inline-block shadow-lg">
                                <div class="card-img-top">
                                    <img src="../assets/p4.jpg" alt="Member" class="img-fluid border-radius p-3"">
                                </div>
                                <div class=" card-body">
                                    <h3 class="card-title"> Max </h3>
                                    <p class="card-text">


                                    </p>
                                    <a href="#" class="text-seconday text-decoration-none">View profile</a>
                                    <p class="text-black-50">Expert In furniture</p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="card mr-2 d-inline-block shadow-lg">
                                <div class="card-img-top">
                                    <img src="../assets/p3.jpg" alt="Member" class="img-fluid border-radius p-3"">
                                </div>
                                <div class=" card-body">
                                    <h3 class="card-title"> Chetan </h3>
                                    <p class="card-text">


                                    </p>
                                    <a href="#" class="text-seconday text-decoration-none">View profile</a>
                                    <p class="text-black-50">Expert In furniture</p>
                                </div>
                            </div>
                        </div>

                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls3"
                        data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls3"
                        data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
            <div class="col-md-4">
                <div id="carouselExampleControls4" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="card mr-2 d-inline-block shadow-lg">
                                <div class="card-img-top">
                                    <img src="../assets/p1.jpg" alt="Member" class="img-fluid border-radius p-3"">
                                </div>
                                <div class=" card-body">
                                    <h3 class="card-title"> Sagar </h3>
                                    <p class="card-text">


                                    </p>
                                    <a href="#" class="text-seconday text-decoration-none">View profile</a>
                                    <p class="text-black-50">Expert In Interior design</p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="card mr-2 d-inline-block shadow-lg">
                                <div class="card-img-top">
                                    <img src="../assets/p5.jpg" alt="Member" class="img-fluid border-radius p-3"">
                                </div>
                                <div class=" card-body">
                                    <h3 class="card-title"> sk </h3>
                                    <p class="card-text">


                                    </p>
                                    <a href="#" class="text-seconday text-decoration-none">View profile</a>
                                    <p class="text-black-50">Expert In painting</p>
                                </div>
                            </div>
                        </div>

                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls4"
                        data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls4"
                        data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
            <div class="col-md-4">
                <div id="carouselExampleControls5" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active text-center">
                            <div class="card mr-2 d-inline-block shadow-lg">
                                <div class="card-img-top">
                                    <img src="../assets/p6.jpg" alt="Member" class="img-fluid border-radius p-3"">
                                </div>
                                <div class=" card-body">
                                    <h3 class="card-title"> Jaggu </h3>
                                    <p class="card-text">


                                    </p>
                                    <a href="#" class="text-seconday text-decoration-none">View profile</a>
                                    <p class="text-black-50">Expert In carpenter</p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="card mr-2 d-inline-block shadow-lg">
                                <div class="card-img-top">
                                    <img src="../assets/pp2.jpg" alt="Member" class="img-fluid border-radius p-3"">
                                </div>
                                <div class=" card-body">
                                    <h3 class="card-title"> Honey </h3>
                                    <p class="card-text">


                                    </p>
                                    <a href="#" class="text-seconday text-decoration-none">View profile</a>
                                    <p class="text-black-50">Expert In Electronic</p>
                                </div>
                            </div>
                        </div>

                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls5"
                        data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls5"
                        data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
    </div>



    <div class="footer">
        <p>copyright @homeservice 2022</p>
    </div>
    </div>

</body>

</html>