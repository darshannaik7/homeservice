<?php
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">


<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home service</title>

<!--home service-->
<link rel="icon" href="../assets/logo1.png">
<!--css-->
<link rel="stylesheet" href="../css/mybookings.css">

<!--bootstrap-->
<link rel="stylesheet" href="../bootstrap/bootstrap.min.css">

<script src="../bootstrap/bootstrap.min.js"></script>
<script src="../bootstrap/jquery.min.js"></script>
<!--themifi-->
<link rel="stylesheet" href="../css/themify-icons.css">
<style>
.col-md-4 {
    border: 1px solid gray;
}

.col-md-6 {
    border: 1px solid gray;

}
</style>

</head>

<body>
    <Header>

        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                    <img src="../assets/logo1.png">
                    Home service
                </a>
                <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbar">
                    <span class="ti-align-justify navbar-toggler-icon "></span>
                </button>
                <div class="navbar-collapse collapse" id="navbar">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="mybookings.php">My Bookings</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profiles.php">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>

                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </Header>
    <div class="section1">
        <div class="container text-center">
            <h1>Booking Details</h1>
        </div>
        <div class="container">
            <form action="mybookings.php" method="POST">
                <input type="text" placeholder="Enter Order no." name='id'>
                <input type="submit" value="Submit" name="submit" />
            </form>
        </div>
        <div class="line">
            <div class="container">

            </div>
        </div>
    </div>

    <?php


    if (isset($_POST['submit'])) {
        $id = $_POST['id'];
        $query = "SELECT * FROM bookings WHERE id='$id'";
        $result = mysqli_query($connect, $query);
        $row = mysqli_fetch_array($result);

    ?>

    <div class="section-2">
        <div class="form">

            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <h6>Name</h6>
                    </div>
                    <div class="col-md-6">
                        <div class="details">
                            <h6> <?php echo $row['name']; ?></h6>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h6>Mobile No.</h6>
                    </div>
                    <div class="col-md-6">
                        <div class="details">
                            <h6><?php echo $row['mobile']; ?></h6>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h6>Alternate Mobile no.</h6>
                    </div>
                    <div class="col-md-6">
                        <div class="details">
                            <h6><?php echo $row['alt_mobile']; ?> </h6>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h6>Email</h6>
                    </div>
                    <div class="col-md-6">
                        <div class="details">
                            <h6><?php echo $row['email']; ?> </h6>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h6>Address</h6>
                    </div>
                    <div class="col-md-6">
                        <div class="details">
                            <h6><?php echo $row['address']; ?> </h6>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h6>Pin code</h6>
                    </div>
                    <div class="col-md-6">
                        <div class="details">
                            <h6><?php echo $row['pincode']; ?> </h6>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h6>Booking Status</h6>
                    </div>
                    <div class="col-md-6">
                        <div class="details">
                            <h6> <?php echo $row['status']; ?> </h6>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h6>Service Man</h6>
                    </div>
                    <div class="col-md-6">
                        <div class="details">
                            <h6> </h6>
                        </div>
                    </div>

                </div>

                <?php  } ?>

            </div>
        </div>

</body>

</html>