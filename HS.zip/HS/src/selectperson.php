<?php
include "config.php";
?>

<!DOCTYPE html>
<html lang="en">


<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home service</title>

<!--home service-->
<link rel="icon" href="../assets/logo1.png">
<!--css-->
<link rel="stylesheet" href="../css/selectperson.css">

<!--bootstrap-->
<link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
<script src="../bootstrap/bootstrap.min.js"></script>
<!--themifi-->
<link rel="stylesheet" href="../css/themify-icons.css">


</head>

<body>
    <Header>

        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                    <img src="../assets/logo1.png">
                    Home service
                </a>
                <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbar">
                    <span class="ti-align-justify navbar-toggler-icon "></span>
                </button>
                <div class="navbar-collapse collapse" id="navbar">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="mybookings.php">My Bookings</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profiles.php">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>

                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </Header>
    <?php

    //put your code above here 

    $name = $_GET['name'];
    $query = "SELECT*FROM tblprofile where product='$name'";
    $result = mysqli_query($connect, $query);
    $row = mysqli_fetch_array($result);
    if ($row != 0) {
    ?>


    <div class="content">
        <div class="container text-center">
            <h1>Book The Service Man You Want</h1>
        </div>
        <div class="container-fluid">
            <div class="products">
                <div class="row">
                    <?php
                        $i = 1;
                        while ($row = mysqli_fetch_array($result)) {
                        ?>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header"> <?php echo $row['product'];
                                                                echo " service" ?></div>
                            <div class="card-img">

                                <img src="../assets/p1.jpg" alt="">
                                <h4><?php echo $row['first_name'];
                                            echo " "; ?><?php echo $row['last_name']; ?></h4>
                                <h6>Qualification/Experience: </h6>
                                <p><?php echo $row['qualification']; ?></p>

                            </div>

                            <div class=" card-body">

                                <p class="card-title">Services available at <?php echo $row['city']; ?></p>

                            </div>
                            <div class="card-footer">
                                <button data-bs-toggle="modal" data-bs-target="#exampleModal">Book This Person</button>
                            </div>

                        </div>
                    </div>

                    <?php $i++;
                        }
                    } else {
                        echo 'No profiles found!';
                    }
                    ?>

                </div>





                <div class="modal1">
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">

                                <div class="modal-body">
                                    <div align="right"><button type="button" class="ti-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button></div>
                                    <div class="form">

                                        <div class="text">
                                            <h2>Fill your Details</h2>
                                        </div>
                                        <form action=selectperson.php method="POST">
                                            <input type="text" name="name" placeholder="Your Name" required>
                                            <input type="text" name="mobileno" placeholder="Mobile No." required>
                                            <input type="text" name="altmobileno" placeholder="Alternate Mobile No.">

                                            <input type="email" name="email" placeholder="Email" required>
                                            <input type="text" name="address" placeholder="Address" required>
                                            <input type="text" name="pincode" placeholder="Area Pin Code" required>
                                            <input type="text" name="serviceman" placeholder="Service man">
                                            <input type="text" name="booked service" placeholder="Service">


                                            <div class="rbt">
                                                <input type="submit" name="submit" value="Submit" onclick="msg()">

                                        </form>
                                    </div>
                                    <div class="modal-footer">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <?php
                    if (isset($_POST['submit'])) {


                        $name = $_POST['name'];
                        $address    = $_POST['address'];
                        $mobile_no  = $_POST['mobileno'];
                        $altmobile_no  = $_POST['altmobileno'];
                        $email       = $_POST['email'];
                        $pincode = $_POST['pincode'];



                        $sql = "INSERT INTO bookings(name,mobile,alt_mobile,address,email,pincode) VALUES('$name','$mobile_no','$altmobile_no','$address','$email','$pincode')";


                        if (mysqli_query($connect, $sql)) {
                            echo '<script> alert("Booking Done. Please keep this order id ") </script>';
                            echo "<script type='text/javascript'> document.location ='mybookings.php'; </script>"; ?>

                <?php
                        } else { ?>
                <script>
                alert("failed");
                </script>
                <?php
                        }
                    }
                    mysqli_close($connect);
                    ?>






            </div>
        </div>
    </div>
</body>

</html>