<?php
require_once "config.php";
?>

<!DOCTYPE html>
<html lang="en">


<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="vsiewport" content="width=device-width, initial-scale=1.0">
<title>Home service</title>

<!--home service-->
<link rel="icon" href="../assets/logo1.png">
<!--css-->
<link rel="stylesheet" href="../css/registration.css">

<!--bootstrap-->
<link rel="stylesheet" href="../bootstrap/bootstrap.min.css">

<script src="../bootstrap/bootstrap.min.js"></script>
<script src="../bootstrap/jquery.min.js"></script>
<!--themifi-->
<link rel="stylesheet" href="../css/themify-icons.css">
<style>
.save input {
    background: darkblue;
    color: white;

}
</style>

</head>

<body>
    <Header>

        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                    <img src="../assets/logo1.png">
                    Home service
                </a>
                <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbar">
                    <span class="ti-align-justify navbar-toggler-icon "></span>
                </button>
                <div class="navbar-collapse collapse" id="navbar">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="mybookings.php">My Bookings</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profiles.php">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact Us</a>
                        </li>


                    </ul>
                </div>
            </div>
        </nav>
    </Header>
    <div class="section1">

    </div>
    <div class="section-2">
        <form action="registration.php" method="POST" onsubmit="return validateForm()">
            <div class="form">
                <div class="container text-center">
                    <h1>Registration Form</h1>
                </div>
                <div class="line">
                    <div class="container">

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <input name="first_name" id="first_name" type="text" placeholder="Enter First Name" required>
                        <span id="blankMsg" style="color:red"> </span>
                    </div>
                    <div class="col-md-4">
                        <input name="last_name" id="last_name" type="text" placeholder="Enter Last Name" required>
                        <span id="charMsg" style="color:red"> </span>
                    </div>
                    <div class="col-md-4">

                        <input name="address" type="address" placeholder="Enter Your Address" required>
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-4">
                        <input name="mobile_no" type="text" placeholder="Enter Mobile No." required>

                    </div>
                    <div class="col-md-4">
                        <input name="email" type="email" placeholder="Enter email" required>
                    </div>
                    <div class="col-md-4">
                        <input name="qualification" type="text" placeholder="Qualification/experience" required>
                    </div>
                </div>
                <div class="row">


                    <div class="col-md-4">
                        <input name="city" type="text" placeholder="city in which you can make service" required>
                    </div>
                    <div class="col-md-4">
                        <input name="new_pass" id="new_pass" type="password" placeholder="New password" required>
                        <span id="message1" style="color:red"> </span> <br>
                    </div>
                    <div class="col-md-4">
                        <input name="confirm_pass" id="confirm_pass" type="password" placeholder="Confirm Password"
                            required>
                        <span id="message2" style="color:red"> </span> <br><br>
                    </div>

                    <div class="col-md-4">
                        <p style="font-size:large">Gender:
                            <select Name="gender" placeholder="">
                                <option>Male</option>
                                <option> Female</option>

                                <option> Other</option>
                            </select>
                        </p>


                    </div>
                    <div class="col-md-8">
                        <p style="font-size:large">Service you can make :
                            <select Name="service" placeholder="">
                                <?php
                                $query = "SELECT*FROM services ORDER BY name ASC";
                                $result = mysqli_query($connect, $query);



                                ?>

                                <?php
                                $i = 1;
                                while ($row = mysqli_fetch_array($result)) {
                                ?>

                                <option><?php echo $row['name']; ?></option>
                                <?php $i++;
                                }
                                ?>

                            </select>
                        </p>


                    </div>
                    <div class="row">
                        <div class="container" align=center>
                            <div class="save" style=width:300px>
                                <input class="btn btn-primary" name="register" type="submit" value="Register" />
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </form>
    </div>

    <?php
    if (isset($_POST['register'])) {

        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $address    = $_POST['address'];
        $mobile_no  = $_POST['mobile_no'];
        $email       = $_POST['email'];
        $qualification = $_POST['qualification'];
        $city =        $_POST['city'];
        $new_pass = $_POST['new_pass'];
        $confirm_pass = $_POST['confirm_pass'];
        $gender = $_POST['gender'];
        $service = $_POST['service'];

        $sql = "INSERT INTO tblprofile(first_name,last_name,tbladdress,mobile,email,gender,qualification,product,city,pasword)VALUES('$first_name','$last_name','$address','$mobile_no','$email','$gender',
        '$qualification','$service','$city','$new_pass')";


        if (mysqli_query($connect, $sql)) {
            echo '<script> alert("Registration Done. Please login...") </script>';
            echo "<script type='text/javascript'> document.location ='profiles.php'; </script>"; ?>

    <?php
        } else { ?>
    <script>
    alert("Email or MobileNo already exist");
    </script>
    <?php
        }
    }
    ?>

</body>
<script>
function validateForm() {
    //collect form data in JavaScript variables  
    var pw1 = document.getElementById("new_pass").value;
    var pw2 = document.getElementById("confirm_pass").value;
    var name1 = document.getElementById("first_name").value;
    var name2 = document.getElementById("last_name").value;

    //check empty first name field  
    if (name1 == "") {
        document.getElementById("blankMsg").innerHTML = "**Fill the first name";
        return false;
    }

    //character data validation  
    if (!isNaN(name1)) {
        document.getElementById("blankMsg").innerHTML = "**Only characters are allowed";
        return false;
    }

    //character data validation  
    if (!isNaN(name2)) {
        document.getElementById("charMsg").innerHTML = "**Only characters are allowed";
        return false;
    }

    //check empty password field  
    if (pw1 == "") {
        document.getElementById("message1").innerHTML = "**Fill the password please!";
        return false;
    }

    //check empty confirm password field  
    if (pw2 == "") {
        document.getElementById("message2").innerHTML = "**Enter the password please!";
        return false;
    }

    //minimum password length validation  
    if (pw1.length < 4) {
        document.getElementById("message1").innerHTML = "**Password length must be atleast 8 characters";
        return false;
    }

    //maximum length of password validation  
    if (pw1.length > 15) {
        document.getElementById("message1").innerHTML = "**Password length must not exceed 15 characters";
        return false;
    }

    if (pw1 != pw2) {
        document.getElementById("message2").innerHTML = "**Passwords are not same";
        return false;
    } else {


    }
}
</script>

</html>